#pragma once
#include <stdint.h>

int32_t print_bank_accounts();
int32_t update_bank_accounts(int32_t n, char** nr);
