#pragma once
#include <stdint.h>

int32_t init_fuel_tank();
int32_t print_fuel_tank();
int32_t update_fuel_tank(int32_t n, char** nr);
