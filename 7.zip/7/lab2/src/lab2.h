#pragma once
#include <stdint.h>

int32_t init_numbers();
int32_t print_numbers();
int32_t sort_numbers();
