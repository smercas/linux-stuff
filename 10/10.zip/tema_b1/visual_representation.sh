#!/bin/bash
./bin/main 3 3 &
ps --forest
