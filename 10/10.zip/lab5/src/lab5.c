/*
  Program: șablonul de creare a N fii ai procesului curent.
*/
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <regex.h>

#define rgin_rc_err { fprintf(stderr, "%s: Error encountered while compiling a regular expression. (%s)\n", __func__, pattern); return -1; }
#define rgin_re_err { fprintf(stderr, "%s: Error encountered while matching a char array to a reguar expression.\n", __func__); return -2; }
#define rgin_nan_err { fprintf(stderr, "%s: The recieved input string '%s' does not qualify as a valid number (must be an greater than 0 integer).\n", __func__, v); return -3; }

#define m_bac_err { fprintf(stderr, "%s: The number of arguments that have been passed is %d when it should be less than %d.\n", __func__, argc - 1, 2); return -1; }
#define m_rgin_err { fprintf(stderr, "%s: Error encountered while recieving an input number (%s).\n", __func__, number); return -2; }
#define m_f_err { fprintf(stderr, "%s: Error encountered while creating a child process.\n", __func__); return -3; }
#define m_w_err { fprintf(stderr, "%s: Error encountered while waiting for a child process to end.\n", __func__); return -4; }

//  -1 regcomp
//  -2 regexec
//  -3 not a number
int32_t recieve_gt0_int_number(char* v, uint64_t *n) {
  regex_t reg;
  int32_t ret;
  char* pattern = "^[1-9][0-9]*$";
  if (regcomp(&reg, pattern, REG_EXTENDED) != 0) rgin_rc_err

  if ((ret = regexec(&reg, v, 0, NULL, 0)) == _REG_NOMATCH) rgin_nan_err
  regfree(&reg);
  if (ret != 0) rgin_re_err
  *n = strtoull(v, NULL, 10);
  return 0;
}

//  -1 - bad argument count
//  -2 - recieve_gt0_int_number
//  -3 - fork
//  -4 - wait
int32_t main(int32_t argc, char* argv[])
{
  char number[128];
  int32_t code;
  uint64_t n, i;
  pid_t pid;

  if (argc - 1 >= 2) m_bac_err

  if (argc - 1 >= 1) strcpy(number, argv[1]);

  while ((code = recieve_gt0_int_number(number, &n)) == -3) {
    printf("insert another number here (remember, it must be an integer that's greater than zero): ");
    scanf("%s", number);
  }
  if (code < 0) m_rgin_err

  printf("Initial process PID: %d, parent process' PID: %d.\n", getpid(), getppid());

  //  branching into n + 1 processes (1 parent, n children)
  for(i = 1; i <= n; ++i) {
    switch (pid = fork()) {
      case -1:
        m_f_err
        break;
      case  0:
        printf("Child process number %lu (PID = %d, parent process' PID = %d).\n", i, getpid(), getppid());
        return i;   //IMPORTANT: child process mustn't continue executing the for loop in order for him to not create more processes
      default:
        break;
    }
  }

  // wait for all n child processes to end
  for(i = 1; i <= n; ++i) {         //  parent process will wait all the child processes to end(some might have already ended)
    if (wait(NULL) == -1) m_w_err   //  some child processes might apprear as orphans(parent process' PID is 1)
  }
  return 0;
}
#undef rgin_rc_err
#undef rgin_re_err
#undef rgin_nan_err

#undef m_bac_err
#undef m_rgin_err
#undef m_f_err
#undef m_w_err
