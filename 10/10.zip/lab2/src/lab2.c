#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>

//  0 - if, else
//  1 - switch
#define if_else_or_switch 1

#define m_f_err { fprintf(stderr, "%s: Error encountered while creating a child process.\n", __func__); return -1; }

//  -1 - fork
int main()
{
  pid_t child_pid;
  int number = 0;

#if if_else_or_switch == 0

  //  the creation of a child process
  if((child_pid = fork()) == -1) m_f_err

  //  execution branching
  if(child_pid == 0)
  {
    //  This code sequence will be executed only by child processes
    printf("Child process' PID: %d\nIts parent's PID: %d.\n\n", getpid(), getppid());
    printf("Within the child process: shortly after calling fork(), the 'number' variable will have the following value: %d.\n", number);
    number = 5;
    printf("Within the child process: after modifying the 'number' variable, it'll will have the following value: %d.\n", number);
  }
  else
  {
    //  his code sequence will only be executed by the parent process
    printf("Parent process' PID: %d\nIts parent's PID: %d;\nIts child's PID: %d.\n\n", getpid(), getppid(), child_pid);
    sleep(2);
    printf("Within the parent process: 2 seconds after branching, the 'number' variable will have the following value: %d.\n", number);
  }

  //  Shared code sequence, executed by both processes
  printf("Shared code sequence, executed by the %s process.\n\n", child_pid == 0 ? "child" : "parent");
  return 0;

#else

  //  the creation of a child process
  child_pid = fork();

  //  execution branching
  switch (child_pid) {
    case -1:
      m_f_err
      break;
    case 0:
      //  This code sequence will be executed only by child processes
      printf("Child process' PID: %d\nIts parent's PID: %d.\n\n", getpid(), getppid());
      printf("Within the child process: shortly after calling fork(), the 'number' variable will have the following value: %d.\n", number);
      number = 5;
      printf("Within the child process: after modifying the 'number' variable, it'll will have the following value: %d.\n", number);
      break;
    default:
      //  his code sequence will only be executed by the parent process
      printf("Parent process' PID: %d\nIts parent's PID: %d;\nIts child's PID: %d.\n\n", getpid(), getppid(), child_pid);
      sleep(2);
      printf("Within the parent process: 2 seconds after branching, the 'number' variable will have the following value: %d.\n", number);
      break;
  }

  //  Shared code sequence, executed by both processes
  printf("Shared code sequence, executed by the %s process.\n\n", child_pid == 0 ? "child" : "parent");
  return 0;

#endif
}

#undef m_f_err
