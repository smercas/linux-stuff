#!/bin/bash
./bin/main &
ps --forest
