/*
  Program: șablonul de creare a N fii ai procesului curent.
*/
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#define gc_f_err { fprintf(stderr, "%s: Error encountered while creating a child process.\n", __func__); return -1; }
#define gc_w_err { fprintf(stderr, "%s: Error encountered while waiting for a child process to end.\n", __func__); return -2; }

#define m_f_err { fprintf(stderr, "%s: Error encountered while creating a child process.\n", __func__); return -1; }
#define m_gc_err { fprintf(stderr, "%s: Error encountered while creating children for a child process.\n", __func__); return -2; }
#define m_w_err { fprintf(stderr, "%s: Error encountered while waiting for a child process to end.\n", __func__); return -3; }

//  -1 - fork
//  -2 - wait
int32_t grandchildren_creation(int32_t k) {
  int32_t i;
  pid_t pid;
  pid_t child[2];
  int32_t code_child[2];
  for (i = 0; i < 2; ++i) {
    pid = fork();
    switch (pid) {
      case -1:
        gc_f_err
        break;
      case  0:
        printf("\t\t(3, %d) PID=%d PPID=%d\n", k * 2 + i + 1, getpid(), getppid());
        sleep(1);
        return i;
      default:
        child[i] = pid;
        break;
    }
  }
  for (i = 0; i < 2; ++i) {
    if (wait(&code_child[i]) == -1) gc_w_err
  }
  printf("\t(2, %d): PID=%d, PPID=%d\n", k + 1, getpid(), getppid());
  for (i = 0; i < 2; ++i) {
    printf("\tchild %d: PID=%d, termination_code=%d\n", i + 1, child[i], code_child[i]);
  }
  return 0;
}

int main() {
  int i;
  pid_t pid;
  pid_t child[5];
  int code_child[5];
  printf("Initial process: PID=%d PPID=%d.\n", getpid(), getppid());

  /* Bucla de producere a primelor 5 procese fii. */
  for (i = 0; i < 5; ++i) {
    pid = fork();
    switch (pid) {
      case -1:
        m_f_err
        break;
      case  0:
        if (grandchildren_creation(i) < 0) m_gc_err
        sleep (1);
        return i;
      default:
        child[i] = pid;
        break;
    }
  }
  //  now we wait
  for (i = 0; i < 5; ++i) {
    if (wait(&code_child[i]) == -1) m_w_err
  }
  printf("(1, 1): PID=%d PPID=%d\n", getpid(), getppid());
  for (i = 0; i < 5; ++i) {
    printf("child %d: %d termination_code=%d\n", i + 1, child[i], code_child[i]);
  }
  return 0;
}
